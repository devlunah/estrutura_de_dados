#include <stdio.h>

int main(){
    // Leia 10 números e mostre apenas os negativos

    int numeros [10];
    
    printf("Insira 10 numeros: ");
    for (int i = 0; i < 10; i++) {
		scanf("%d", & numeros[i]);
	}
    
    int tamanhoArray = sizeof(numeros)/sizeof(numeros[0]);

    printf("Numeros negativos: \n");

    for(int i = 0; i < tamanhoArray; i++){

        if(numeros[i] < 0){ 
            printf("%d \n", numeros[i]);
        }
    }

}
